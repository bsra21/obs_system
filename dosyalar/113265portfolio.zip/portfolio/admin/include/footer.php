</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
    reserved.
</footer>



</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="assets/js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- FastClick -->
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<!-- SlimScroll -->
<script src="assets/js/jquery.slimscroll.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="assets/js/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/js/demo.js"></script>


<script src="assets/js/bootstrap-datepicker.min.js"></script>
<script src="assets/js/jquery.inputmask.js"></script>
<script src="assets/js/jquery.inputmask.extensions.js"></script>
<script src="assets/js/jquery.inputmask.phone.extensions.js"></script>
<script src="assets/js/jquery.inputmask.date.extensions.js"></script>
<script src="assets/js/select2.full.min.js"></script>
</body>
</html>
