<div class="alert alert-success">
<?php 


echo $_POST['isim'];


?>
</div>


