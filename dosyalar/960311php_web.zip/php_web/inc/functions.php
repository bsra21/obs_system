<?php 


  function sayfa_yukle()
  {
      
        $dosya = 'pages/';
      
         
        
        $page = array_key_exists('page', $_GET) ? $_GET['page'] . '.php' : 'anasayfa.php';
      
       
      
       if(!file_exists($dosya.$page)) $page = '404.php';  
        
        include $dosya.$page;
       
      
  }

?>