<?php 

    
    if(array_key_exists('isim',$_POST)){
        
        include 'inc/form.php';
        
    }

?>
 

 <form action="?page=iletisim" method="post">
  <div class="form-group">
    <label for="exampleFormControlInput1">isim</label>
    <input name="isim" type="text" class="form-control" id="exampleFormControlInput1" placeholder="isim">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">mail adres</label>
    <input name="mail" type="email" class="form-control" id="exampleFormControlInput1" placeholder="test@hotmail.com">
  </div>
  
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">mesaj</label>
    <textarea placeholder="mesaj"  name="mesaj" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-success">Gönder</button>
  
</form>














