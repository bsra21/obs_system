<?php
$SayfaDis[0]		=	"anasayfa.php";
$SayfaDis[1]		=	"yoneticigiris.php";
$SayfaDis[2]		=	"yoneticigirissonuc.php";
$SayfaDis[3]		=	"yoneticigirissonuchata.php";
$SayfaDis[4]		=	"yoneticicikis.php";
?>