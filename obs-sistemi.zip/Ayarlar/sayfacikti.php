
<?php   

$Sayfacikti[0]		=	"pdfmodal.php";

$Sayfacikti[1]		=	"anasafya.php";
$Sayfacikti[2]		=	"mesajduzenlepanel.php";




?>