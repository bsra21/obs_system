<?php
$Sayfa[0]		=	"anasayfa.php"; //++
$Sayfa[1]		=	"login.php";  //++
$Sayfa[4]		=	"loginsonuc.php"; //++
$Sayfa[2]		=	"ogrenci.php"; //++
$Sayfa[3]		=	"uyeol.php"; //++
$Sayfa[5]		=	"uyeolsonuc.php";   //++
$Sayfa[6]		=	"ogrencianasayfa.php"; //++
$Sayfa[7]		=	"dersvideolari.php"; //++
$Sayfa[9]		=	"ogrenciprofil.php"; //++
$Sayfa[10]		=	"ogrenciprofilsonuc.php"; //++

$Sayfa[8]		=	"sinavsonuclari.php";
$Sayfa[11]		=	"dersprogrami.php";
$Sayfa[12]		=	"onlinesinav.php";
$Sayfa[13]		=	"odemelerim.php";
$Sayfa[14]		=	"odevler.php";
$Sayfa[15]		=	"ogrencianasayfasonuc.php"; //++
$Sayfa[16]		=	"dersnotlarim.php"; 
$Sayfa[17]		=	"ogrencicikis.php";    //+++++
$Sayfa[18]		=	"ogrencimesajeklesonuc.php";   //++
$Sayfa[19]		=	"ogrencimesajsilsonuc.php"; //++ sadece kendi paylaşımlarını siliyor.


//Bütün dersler gözükmesin, sadece bnm sınıfımda bnm aldığım dersler gözüksün. 
//Dokümanlar için de aynı durum,sadece bnm derslerime ait dosyalar gözüksün..
// Benim eğitmenlerimin attığı video-dosya gozuksun.
// ogretmenler diye bir tablo oluşturulabilir. 

?>