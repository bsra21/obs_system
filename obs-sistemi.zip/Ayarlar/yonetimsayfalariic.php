<?php
$SayfaIc[0]			=	"admin.php";  //Eklemeler tamam ////bak-sil-güncelle modal yapılacak
$SayfaIc[1]			=	"profil.php"; //bitti  +++
$SayfaIc[2]			=	"profilguncelle.php"; //bitti  +++
$SayfaIc[3]			=	"dersvevideo.php"; //bitti   ++++
$SayfaIc[4]			=	"derseklesonuc.php";  //bitti +++
$SayfaIc[6]		    =	"derspdf.php"; //pdf + video + ders listeleme
$SayfaIc[11]		=	"derspdfeklesonuc.php";   // +++
$SayfaIc[5]			=	"duyurueklesonuc.php";  //bitti  +++++
$SayfaIc[7]			=	"duyurueklesonuchata.php"; // ++++ GENEL HATA SAYFASI
$SayfaIc[8]			=	"videoeklesonuc.php"; //++++
$SayfaIc[14]		=	"mesajeklesonuc.php";  //bitti her tür ekliyor. ++++++++
$SayfaIc[15]			=	"sliderlistesi.php"; //slider listesi-sadece resim ekleyebildiği  +++++
$SayfaIc[16]			=	"ogrenciler.php"; //++++
$SayfaIc[17]			=	"yoneticicikis.php"; //++
$SayfaIc[18]			=	"slidereklesonuc.php"; //+++
$SayfaIc[19]			=	"slidersilsonuc.php"; //+++  
$SayfaIc[20]			=	"sliderguncellesonuc.php"; //+++++++++
$SayfaIc[23]			=	"metinpaylasimsilsonuc.php"; //+++++
$SayfaIc[24]			=	"metinpaylasimguncellesonuc.php"; //*++  Dosya seçince görüntü vermiyor..
$SayfaIc[25]			=	"mesajDuyuruEklemeSayfasi.php";  //++
$SayfaIc[26]			=	"duyurusilsonuc.php";  //++
$SayfaIc[27]			=	"duyuruguncellesonuc.php"; //++++
$SayfaIc[28]			=	"ogrencisilsonuc.php"; //+++
$SayfaIc[29]			=	"ogrencieklesonuc.php"; // +++
$SayfaIc[32]			=	"derspdfsilsonuc.php"; //++++


$SayfaIc[21]		=	"silinemedi.php"; //GNEL SİLİNEMEDİ MESAJI  ++
$SayfaIc[9]			=	"dersprogramiekle.php"; //-----------------------------------------
$SayfaIc[10]		=	"dersprogramieklesonuc.php"; //-----------
$SayfaIc[12]		=	"odevler.php";   //  ----------
$SayfaIc[13]		=	"odeveklesonuc.php";  //  -----------------------------------------
$SayfaIc[22]		=	"dersprogrami.php"; ///deneme amaçlı açmıştım ----------


//  //////////
$SayfaIc[30]			=	"ogrenciguncellesonuc.php";  // ------------------ !!!!!!!!!!!!!!!
$SayfaIc[31]			=	"ogrencidetaysonuc.php";  //sınav sonuçlarını görsün- başka sayfada 
 // baska sayfada hem kimlik bilgiler, hem notları-başarısı gözüksün.. -------------
$SayfaIc[33]			=	//boş
$SayfaIc[34]			=	"ogrenciekle.php";  //+++
$SayfaIc[35]			=	"sinifeklesonuc.php"; //+++
$SayfaIc[36]			=	"siniflar.php";   // ++++
$SayfaIc[37]			=	"sinifsilsonuc.php";     //++
$SayfaIc[38]		=	"derspdfekle.php"; //++
$SayfaIc[39]		=	"videosilsonuc.php"; //+++
$SayfaIc[40]		=	"derssilsonuc.php"; //++
$SayfaIc[41]		=	"videoguncellesonuc.php";





//video güncelle
//dokümanlarda gözükmesini istediğimiz sınıfları da ekleyebilrisin...
// videolar seçilen sınıflara gözüksün sadece
// Admin haftalık ders programını sınıfa göre yapsın ve o sınıfın öğrencilerinde gözüksün..
//Canlı ders linki koy,Birden fazla sınıfı olabilir, hepsine farklı link verebilir. Ona göre düzenle
//Online sınav için: Hangi sınıf,hangi dersten,hangi saatte sınav olacak. //Hoca soruları aktarcak.
//slider resim değişmese de güncellemee yapabilsin..
//admin pdf tablosunda yayın tarihi ve yayınlayan kişi yok..
//paylaşım güncelle
?>