

<?php 
echo(" Hatalı giriş denemesi .Tekrar deneyiniz.");
header("Location:index.php?SKD=1"); 
?>
