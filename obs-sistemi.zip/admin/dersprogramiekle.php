<?php 
if(isset($_SESSION["Yonetici"])){

	












	
}else{
	header("Location:index.php?SKD=1");
	exit();
}
?>
