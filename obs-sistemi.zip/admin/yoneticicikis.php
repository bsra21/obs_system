<?php
unset($_SESSION["Yonetici"]);
session_destroy();

unset($_SESSION["Ogretmen"]);
session_destroy();

header("Location:index.php");
exit();
?>