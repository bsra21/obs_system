

<div class="alert alert-danger" role="alert">
  

Eklerken bir hata oluştu. Dosya boyutuna, uzantısına dikkat ediniz. 

</div>

<a href="index.php?SKD=0&SKI=0">
 
<button type="button" class="btn btn-danger" >Anasayfaya Dön</button>
</a>

