
<div class="alert alert-danger" role="alert">
  
Silinme işlemi gerçekleşemedi. Daha sonra tekrar deneyiniz..

</div>

<a href="index.php?SKD=0&SKI=1">
 
<button type="button" class="btn btn-danger" >Anasayfaya Dön</button>
</a>
